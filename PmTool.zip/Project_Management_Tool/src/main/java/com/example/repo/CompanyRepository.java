package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Company;

public interface CompanyRepository extends JpaRepository<Company,Long>
{

	Company save(Company company);

	Company findByEmail(String email); 
	

}
