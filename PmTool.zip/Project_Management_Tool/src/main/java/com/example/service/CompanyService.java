package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Company;
import com.example.repo.CompanyRepository;
import com.example.util.BCryptUtil;

@Service
public class CompanyService {

    @Autowired
    private CompanyRepository companyRepository;

    public Company saveCompany(Company company) throws IllegalArgumentException {
        if (!company.getCreate_Password().equals(company.getConfirm_Password())) {
            throw new IllegalArgumentException("Passwords do not match");
        }

        String hashedPassword = BCryptUtil.hashPassword(company.getCreate_Password());
        company.setCreate_Password(hashedPassword);
        return companyRepository.save(company);
    }
    }

    



