package com.example.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Employee;
import com.example.repo.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private MailService mailService;

    public Employee registerEmployee(Employee employee) {
        String tempPassword = mailService.sendTemporaryPassword(employee.getEmailId());
        employee.setTemporaryPassword(tempPassword);
        return employeeRepository.save(employee);
    }

    public Employee findByEmailId(String emailId) {
        return employeeRepository.findByEmailId(emailId);
    }

    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }
}
