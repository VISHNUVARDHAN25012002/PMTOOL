package com.example.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Employee;
import com.example.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/register")
    public String showRegistrationForm() {
        return "register";
    }

    @PostMapping("/register")
    public String registerEmployee(Employee employee) {
        employeeService.registerEmployee(employee);
        return "redirect:/employees/register?success";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "emplogin";
    }

    @PostMapping("/login")
    public String loginEmployee(@RequestParam String emailId, @RequestParam String password) {
        Employee employee = employeeService.findByEmailId(emailId);
        if (employee != null && (password.equals(employee.getTemporaryPassword()) || password.equals(employee.getPermanentPassword()))) {
            return "redirect:/employees/resetPassword?emailId=" + emailId;
        }
        return "redirect:/employees/emplogin?error";
    }

    @GetMapping("/resetPassword")
    public String showResetPasswordForm(@RequestParam String emailId, Map<String, Object> model) {
        model.put("emailId", emailId);
        return "resetPassword";
    }

    @PostMapping("/resetPassword")
    public String resetPassword(@RequestParam String emailId, @RequestParam String newPassword) {
        Employee employee = employeeService.findByEmailId(emailId);
        if (employee != null) {
            employee.setPermanentPassword(newPassword);
            employeeService.save(employee);
            return "redirect:/employees/emplogin?passwordResetSuccess";
        }
        return "redirect:/employees/resetPassword?error";
    }
}

