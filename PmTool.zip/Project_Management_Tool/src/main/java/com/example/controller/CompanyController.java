package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.entity.Company;
import com.example.service.CompanyService;
//import com.example.service.EmailService;

@Controller
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @GetMapping("/signup")
    public String showSignUpForm(Model model) {
        model.addAttribute("company", new Company());
        return "sign_up_page";
    }

   /* @PostMapping("/signup")
    public String registerCompany(@ModelAttribute("company") Company company) {
        companyService.saveCompany(company);
        emailService.sendRegistrationSuccessEmail(company.getEmail(), company.getName());
        return "sucess";
    }*/
    
    @GetMapping("/sucess")
    public String showSuccessPage() {
        return "sucess";
    }
}
