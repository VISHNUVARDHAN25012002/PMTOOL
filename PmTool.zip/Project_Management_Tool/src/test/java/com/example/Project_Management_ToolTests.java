package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project_Management_ToolTests {

	@Test
	void contextLoads() {
	}

}
